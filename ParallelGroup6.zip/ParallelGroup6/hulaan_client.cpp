#include <iostream>
#include <string>
#include <thread>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

const char* SERVER_HOST = "database.tambytes.cloud";
const int PORT = 12345;

void receiveMessages(SOCKET sock) {
    char buffer[1024];
    while (true) {
        memset(buffer, 0, sizeof(buffer));
        int bytes = recv(sock, buffer, sizeof(buffer), 0);
        if (bytes <= 0) break;
        cout << buffer;
    }
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed.\n";
        return 1;
    }

    addrinfo hints{}, *res;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    if (getaddrinfo(SERVER_HOST, to_string(PORT).c_str(), &hints, &res) != 0) {
        cerr << "getaddrinfo failed.\n";
        WSACleanup();
        return 1;
    }

    SOCKET sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sock == INVALID_SOCKET) {
        cerr << "Socket creation failed.\n";
        freeaddrinfo(res);
        WSACleanup();
        return 1;
    }

    if (connect(sock, res->ai_addr, res->ai_addrlen) == SOCKET_ERROR) {
        cerr << "Connection failed.\n";
        closesocket(sock);
        freeaddrinfo(res);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(res);

    thread recvThread(receiveMessages, sock);

    string input;
    while (getline(cin, input)) {
        send(sock, input.c_str(), input.size(), 0);
    }

    recvThread.join();
    closesocket(sock);
    WSACleanup();
    return 0;
}